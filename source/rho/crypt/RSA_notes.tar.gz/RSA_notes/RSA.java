import java.math.BigInteger;
import java.security.SecureRandom;

class RSA
{
    private BigInteger n, e, d;        // <-- (n, e) is the public key, (n, d) is the private key

    public RSA(int bitlen)
    {
        SecureRandom r = new SecureRandom();
        BigInteger p = null;
        BigInteger q = null;
        do
        {
            p = new BigInteger(bitlen / 2, 100, r);   // <-- ensures first bit of generated number is 1
            q = new BigInteger(bitlen / 2, 100, r);   // <-- ensures first bit of generated number is 1
        } while (p.equals(q));

        n = p.multiply(q);                            // <-- n is either 'bitlen' bits or 'bitlen-1' bits

        BigInteger m = (p.subtract(BigInteger.ONE))
            .multiply(q.subtract(BigInteger.ONE));

        e = new BigInteger("65537");                  // <-- 65537 is the recommended choice for e, but it could be anything
        while(m.gcd(e).intValue() > 1) e = e.add(new BigInteger("2"));

        d = e.modInverse(m);

        System.out.println("p = " + p);
        System.out.println("q = " + q);
        System.out.println("n = " + n);
        System.out.println("m = " + m);
        System.out.println("e = " + e);
        System.out.println("d = " + d);
        System.out.println();
    }

    public BigInteger encrypt(BigInteger message)
    {
        return message.modPow(e, n);
    }

    public BigInteger decrypt(BigInteger message)
    {
        return message.modPow(d, n);
    }
    
    public static void main(String[] args)
    {
    	int numbits = 512;         // <-- usually 1024 up to 4096  (could be anything, but a key of length 768 or less can be broken!)
    	RSA rsa = new RSA(numbits);

    	System.out.println("First \"too big\" message will be " + rsa.n);

    	BigInteger message = rsa.n.subtract(new BigInteger("30"));

    	while (true)
    	{
        	message = message.add(BigInteger.ONE);
        	System.out.print(message);
        	BigInteger ciphertext = rsa.encrypt(message);
        	System.out.print(" -> " + ciphertext);
        	BigInteger message2 = rsa.decrypt(ciphertext);
        	System.out.println(" -> " + message2);
        	if (! message.equals(message2))
        		break;
    	}
    }
}
